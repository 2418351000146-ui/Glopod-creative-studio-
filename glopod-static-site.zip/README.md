# GLOPOD — Static Site

Plain HTML/CSS/JS. No build step, no npm, no framework. Works by double-clicking
index.html locally, and works as-is on GitHub Pages or Cloudflare Pages.

## Folder structure

```
/
├── index.html
├── css/
│   └── styles.css
├── js/
│   ├── main.js            (scroll reveal, pinned services/capabilities/process, contact fade)
│   └── averin-router.js   (hash-based #/averin case-study view)
├── images/
│   ├── averin-logo.png
│   ├── averin-emblem.svg
│   ├── object-001-peacock.jpg
│   └── object-002-shift.jpg
└── video/
    └── jellyfish.mp4
```

## External dependencies (only thing not self-hosted)

Google Fonts, loaded via `<link>` in the `<head>`:
DM Mono, DM Sans, Playfair Display, Space Grotesk, JetBrains Mono, Italiana,
Cormorant Garamond — fetched from fonts.googleapis.com / fonts.gstatic.com at
runtime. No API key needed, works on any static host. If you want a fully
offline/self-hosted version instead, say so and the font files can be
downloaded into a `/fonts` folder and referenced with @font-face.

Everything else (all CSS, all JS, all images, the video) is local — no other
network calls, no analytics, no forms that submit anywhere.

## Deploy to GitHub Pages

1. Create a new repo, e.g. `glopod-site`.
2. Push these files so `index.html` sits at the repo root:
   ```
   git init
   git add .
   git commit -m "Initial site"
   git branch -M main
   git remote add origin https://github.com/<you>/glopod-site.git
   git push -u origin main
   ```
3. Repo → Settings → Pages → Source: "Deploy from a branch" → Branch: `main`, folder `/root`.
4. Site goes live at `https://<you>.github.io/glopod-site/`.

## Deploy to Cloudflare Pages

1. Cloudflare dashboard → Workers & Pages → Create → Pages → "Upload assets" (or connect the GitHub repo).
2. If connecting the repo: build command = none, output directory = `/` (root).
3. If uploading directly: drag the whole folder in (the one containing `index.html`).
4. Deploy — Cloudflare gives you a `*.pages.dev` URL immediately.

## Notes

- `jellyfish.mp4` is ~4.1 MB — the single largest asset on the page. If load
  time matters, it's the first thing to compress/trim.
- All internal navigation is hash-based (`#studio`, `#work`, `#/averin`, etc.)
  and needs no server-side routing — this is why it works unmodified on
  static hosts with no rewrite rules.
- Responsive breakpoints are already in `styles.css` at 950px and 650px;
  nothing further is needed for mobile/tablet.
