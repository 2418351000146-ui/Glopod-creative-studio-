/* AVÉRIN inside GLOPOD: "#/averin" shows the case study, any other hash shows the main site.
     Because it is a real history entry, the browser Back button returns to GLOPOD. */
  (function(){
    var view = document.getElementById('averinView');
    if(!view) return;
    var SITE_TITLE = document.title, AV_TITLE = 'AVÉRIN — A Glopod case study';
    var inAverin = false, savedY = 0, cameFromSite = false, pendingAnchor = null, ready = false;
    if('scrollRestoration' in history) history.scrollRestoration = 'manual';

    function isAverin(){ return location.hash === '#/averin'; }
    function jump(y){
      var root = document.documentElement, prev = root.style.scrollBehavior;
      root.style.scrollBehavior = 'auto';
      window.scrollTo(0, y);
      root.style.scrollBehavior = prev;
    }
    function apply(){
      if(isAverin()){
        if(!inAverin){
          savedY = window.scrollY;
          if(ready) cameFromSite = true;
          document.body.classList.add('view-averin');
          inAverin = true;
          document.title = AV_TITLE;
          jump(0);
        }
      } else if(inAverin){
        document.body.classList.remove('view-averin');
        inAverin = false;
        document.title = SITE_TITLE;
        var target = pendingAnchor ? document.getElementById(pendingAnchor) : null;
        pendingAnchor = null;
        if(target){ jump(target.getBoundingClientRect().top + window.scrollY); }
        else { jump(savedY); }
        window.dispatchEvent(new Event('resize'));
        window.dispatchEvent(new Event('scroll'));
      }
    }
    window.addEventListener('hashchange', apply);
    apply(); ready = true;

    /* Back links inside AVÉRIN */
    view.querySelectorAll('[data-av-back]').forEach(function(a){
      a.addEventListener('click', function(e){
        e.preventDefault();
        if(cameFromSite){ history.back(); }
        else { pendingAnchor = 'work'; location.hash = '#work'; }
      });
    });
    view.querySelectorAll('[data-av-anchor]').forEach(function(a){
      a.addEventListener('click', function(e){
        e.preventDefault();
        pendingAnchor = a.getAttribute('data-av-anchor');
        location.hash = '#' + pendingAnchor;
      });
    });

    /* Chapter menu: smooth scroll inside AVÉRIN without changing the address */
    var avLinks = Array.prototype.slice.call(view.querySelectorAll('.av-subnav a'));
    avLinks.forEach(function(a){
      a.addEventListener('click', function(e){
        e.preventDefault();
        var t = document.getElementById(a.getAttribute('href').slice(1));
        if(t) t.scrollIntoView({behavior:'smooth', block:'start'});
      });
    });
    var avChapters = Array.prototype.slice.call(view.querySelectorAll('.av-section[id], .av-cta[id]'));
    if(avChapters.length && 'IntersectionObserver' in window){
      var avObs = new IntersectionObserver(function(entries){
        entries.forEach(function(en){
          if(en.isIntersecting){
            avLinks.forEach(function(a){ a.classList.toggle('is-current', a.getAttribute('href') === '#' + en.target.id); });
          }
        });
      }, {rootMargin:'-45% 0px -45% 0px'});
      avChapters.forEach(function(c){ avObs.observe(c); });
    }
  })();
