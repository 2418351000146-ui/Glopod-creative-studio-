const header = document.getElementById('header');
    const menu = document.getElementById('menu');
    const revealItems = document.querySelectorAll('.reveal');

    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 30);
    }, {passive:true});

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if(entry.isIntersecting) {
          entry.target.classList.add('show');
          observer.unobserve(entry.target);
        }
      });
    }, {threshold:.12});
    revealItems.forEach(el => observer.observe(el));

    menu.addEventListener('click', () => {
      const open = document.body.classList.toggle('menu-open');
      menu.textContent = open ? 'CLOSE' : 'MENU';
    });

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Horizontal storytelling: the intro holds, then normal scroll reveals each card to the right.
    const horizontalSections = document.querySelectorAll('.horizontal-section');
    if(!reducedMotion){
      horizontalSections.forEach(section => {
        const track = section.querySelector('[data-horizontal-track]');
        const progress = section.querySelector('.horizontal-progress i');
        const totalSlides = track.children.length;
        const update = () => {
          const rect = section.getBoundingClientRect();
          const maxScroll = section.offsetHeight - window.innerHeight;
          const progressY = Math.min(Math.max(-rect.top,0),maxScroll);
          const ratio = maxScroll ? progressY / maxScroll : 0;
          track.style.transform = `translate3d(${-ratio * (totalSlides-1) * 100}vw,0,0)`;
          progress.style.width = `${Math.max(14.285, ratio*100)}%`;
        };
        window.addEventListener('scroll', update, {passive:true});
        window.addEventListener('resize', update);
        update();
      });
    }

    // Services: each service rises from below as the visitor scrolls through the pinned frame.
    const servicesSection = document.getElementById('services');
    if(servicesSection){
      const cards = [...servicesSection.querySelectorAll('.service-card')];
      const progress = servicesSection.querySelector('.services-progress i');
      const updateServices = () => {
        const rect = servicesSection.getBoundingClientRect();
        const maxScroll = servicesSection.offsetHeight - window.innerHeight;
        const y = Math.min(Math.max(-rect.top,0),maxScroll);
        const ratio = maxScroll ? y / maxScroll : 0;
        const n = cards.length;
        cards.forEach((card,i) => {
          const start = i / n;
          const end = (i + 1) / n;
          const local = Math.min(1, Math.max(0, (ratio - start) / (end - start)));
          const eased = local * local * (3 - 2 * local);
          const isActive = ratio >= start && ratio <= end + .02;
          card.style.transform = `translate3d(0,${(1-eased)*115}vh,0)`;
          card.style.opacity = isActive || local > .02 ? String(Math.min(1, eased*1.35)) : '0';
          card.style.zIndex = String(10+i);
        });
        progress.style.width = `${ratio*100}%`;
        const intro = servicesSection.querySelector('.services-intro');
        if(intro) intro.style.opacity = String(Math.max(0, 1 - ratio * 10));
      };
      window.addEventListener('scroll', updateServices, {passive:true});
      window.addEventListener('resize', updateServices);
      updateServices();
    }

    // Hero jellyfish video: make sure it plays inline.
    const jellyVideo = document.querySelector('.jelly-image video');
    if(jellyVideo){ jellyVideo.muted = true; const p = jellyVideo.play(); if(p && p.catch) p.catch(()=>{}); }

    // Let's Talk: starts in the same dark world, then dissolves into the lighter closing state.
    const contact = document.getElementById('contact');
    const updateContact = () => {
      if(!contact) return;
      const rect = contact.getBoundingClientRect();
      const travel = Math.max(contact.offsetHeight + window.innerHeight * .35, 1);
      const progress = Math.min(1, Math.max(0, (window.innerHeight - rect.top) / travel));
      contact.style.setProperty('--contact-progress', progress.toFixed(3));
      contact.classList.toggle('contact-light', progress > .58);
    };
    window.addEventListener('scroll', updateContact, {passive:true});
    window.addEventListener('resize', updateContact);
    updateContact();
